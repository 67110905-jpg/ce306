import Navbar from "./component/Neverbar";
import ProductCard from "./component/ProductCard";

const products = [
  {
    imageUrl: "/coffee.jpg",
    title: "เครื่องชงกาแฟ",
    description: "ชงกาแฟสดรสชาติอร่อย ใช้งานง่าย",
    price: 2990,
  },
  {
    imageUrl: "/mouse.jpg",
    title: "เมาส์ไร้สาย",
    description: "ตอบสนองไว เล่นเกมก็ได้ ทำงานก็ดี",
    price: 790,
  },
  {
    imageUrl: "/keyboard.jpg",
    title: "คีย์บอร์ดกลไก",
    description: "เสียงดังมันส์มือ พิมพ์สนุก เล่นเกมมันส์",
    price: 1590,
  },
];

function App() {
  return (
    <div className="min-h-screen bg-gray-100">
      {/* Navbar */}
      <Navbar />

      {/* Main Content */}
      <main className="pt-20 px-6 max-w-7xl mx-auto">
        <h1 className="text-2xl font-bold mb-6">รายการสินค้าของเรา</h1>

        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 md:grid-cols-3">
          {products.map((p, idx) => (
            <ProductCard
              key={idx}
              {...p}
              onAddToCart={() => alert(`เพิ่ม ${p.title} ลงตะกร้าแล้ว!`)}
            />
          ))}
        </div>
      </main>
    </div>
  );
}

export default App;
