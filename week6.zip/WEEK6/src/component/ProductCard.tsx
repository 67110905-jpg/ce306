import React from "react";
import {Button}  from "./ฺฺButton";

type ProductCardProps = {
  imageUrl: string;
  title: string;
  description: string;
  price: number;
  onAddToCart: () => void;
};

const ProductCard: React.FC<ProductCardProps> = ({
  imageUrl,
  title,
  description,
  price,
  onAddToCart,
}) => {
  return (
    <div className="max-w-xs bg-white rounded-2xl shadow-md p-4 flex flex-col">
      <img
        src={imageUrl}
        alt={title}
        className="w-full h-48 object-cover rounded-lg"
      />
      <h3 className="text-lg font-semibold mt-3">{title}</h3>
      <p className="text-gray-600 text-sm line-clamp-2">{description}</p>
      <p className="text-xl font-bold text-blue-600 mt-2">{price.toFixed(2)} ฿</p>
      <Button
        variant="primary"
        className="mt-3 w-full rounded-xl"
        onClick={onAddToCart}
      >
        Add to Cart
      </Button>
    </div>
  );
};

export default ProductCard;
